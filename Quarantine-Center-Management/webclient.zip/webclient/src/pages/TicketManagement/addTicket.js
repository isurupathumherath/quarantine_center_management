import React, { Component } from 'react'; 
import Test1 from '../../components/clientAddTicket'; 


export default class addTicket extends Component {
  render() {
    return (
      <div className="container">
        <div className="row">
          <div className="col-lg-12">
            <Test1 />
          </div>
          </div>
        </div>
     
    )
  }
}
